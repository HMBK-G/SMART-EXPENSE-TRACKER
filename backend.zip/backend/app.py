from flask import Flask, request, jsonify
from flask_cors import CORS
import mysql.connector
from datetime import datetime, timedelta
from config import Config

app = Flask(__name__)
CORS(app)

# MySQL Connection
def get_db_connection():
    return mysql.connector.connect(
        host=Config.MYSQL_HOST,
        user=Config.MYSQL_USER,
        password=Config.MYSQL_PASSWORD,
        database=Config.MYSQL_DATABASE
    )

# Test Connection
@app.route('/api/test', methods=['GET'])
def test():
    try:
        conn = get_db_connection()
        conn.close()
        return jsonify({'status': 'Connected to MySQL successfully'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Get all expenses
@app.route('/api/expenses', methods=['GET'])
def get_expenses():
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute('SELECT * FROM expenses ORDER BY date DESC')
        expenses = cursor.fetchall()
        cursor.close()
        conn.close()
        return jsonify(expenses), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Add new expense
@app.route('/api/expenses', methods=['POST'])
def add_expense():
    try:
        data = request.get_json()
        conn = get_db_connection()
        cursor = conn.cursor()
        
        query = 'INSERT INTO expenses (category, amount, description, date) VALUES (%s, %s, %s, %s)'
        cursor.execute(query, (
            data['category'],
            data['amount'],
            data['description'],
            data['date']
        ))
        
        conn.commit()
        expense_id = cursor.lastrowid
        cursor.close()
        conn.close()
        
        return jsonify({'id': expense_id, 'success': True}), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Delete expense
@app.route('/api/expenses/<int:expense_id>', methods=['DELETE'])
def delete_expense(expense_id):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM expenses WHERE id = %s', (expense_id,))
        conn.commit()
        cursor.close()
        conn.close()
        return jsonify({'success': True}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Update expense
@app.route('/api/expenses/<int:expense_id>', methods=['PUT'])
def update_expense(expense_id):
    try:
        data = request.get_json()
        conn = get_db_connection()
        cursor = conn.cursor()
        
        query = 'UPDATE expenses SET category=%s, amount=%s, description=%s, date=%s WHERE id=%s'
        cursor.execute(query, (
            data['category'],
            data['amount'],
            data['description'],
            data['date'],
            expense_id
        ))
        
        conn.commit()
        cursor.close()
        conn.close()
        return jsonify({'success': True}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Get all budgets
@app.route('/api/budgets', methods=['GET'])
def get_budgets():
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute('SELECT category, monthly_limit as amount FROM budgets')
        budgets = cursor.fetchall()
        cursor.close()
        conn.close()
        
        # Format as expected by frontend
        result = {'monthly': 0, 'categoryBudgets': {}}
        for budget in budgets:
            if budget['category'] == 'total':
                result['monthly'] = budget['amount']
            else:
                result['categoryBudgets'][budget['category']] = budget['amount']
        
        return jsonify(result), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Update budget
@app.route('/api/budgets', methods=['PUT'])
def update_budgets():
    try:
        data = request.get_json()
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Update monthly budget
        if 'monthly' in data:
            cursor.execute(
                'UPDATE budgets SET monthly_limit=%s WHERE category=%s',
                (data['monthly'], 'total')
            )
        
        # Update category budgets
        if 'categoryBudgets' in data:
            for category, amount in data['categoryBudgets'].items():
                cursor.execute(
                    'UPDATE budgets SET monthly_limit=%s WHERE category=%s',
                    (amount, category)
                )
        
        conn.commit()
        cursor.close()
        conn.close()
        return jsonify({'success': True}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Get AI spending insights
@app.route('/api/insights', methods=['GET'])
def get_insights():
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Get all expenses
        cursor.execute('SELECT * FROM expenses ORDER BY date DESC')
        expenses = cursor.fetchall()
        
        # Get all budgets
        cursor.execute('SELECT category, monthly_limit as amount FROM budgets')
        budgets = cursor.fetchall()
        cursor.close()
        conn.close()
        
        insights = []
        
        # Get current and last month
        now = datetime.now()
        current_month = now.strftime('%Y-%m')
        last_month = (now.replace(day=1) - timedelta(days=1)).strftime('%Y-%m')
        
        # Filter expenses by month
        current_month_expenses = [exp for exp in expenses if exp['date'].startswith(current_month)]
        last_month_expenses = [exp for exp in expenses if exp['date'].startswith(last_month)]
        
        # Calculate totals
        current_total = sum(exp['amount'] for exp in current_month_expenses)
        last_total = sum(exp['amount'] for exp in last_month_expenses)
        
        # Get budget limits
        budget_dict = {b['category']: b['amount'] for b in budgets}
        monthly_budget = budget_dict.get('total', 50000)
        
        # 1. Budget overspend prediction
        days_in_month = (now.replace(day=1) + timedelta(days=32)).replace(day=1) - timedelta(days=1)
        day_of_month = now.day
        if day_of_month > 0:
            daily_average = current_total / day_of_month
            projected = daily_average * days_in_month.day
            
            if projected > monthly_budget and current_total > 0:
                overspend = projected - monthly_budget
                insights.append({
                    'id': 'overspend-prediction',
                    'type': 'warning',
                    'title': 'Budget Alert',
                    'message': f"At this rate, you may exceed your budget by ₹{int(overspend):,} this month.",
                    'icon': '⚠️'
                })
        
        # 2. Compare spending with last month
        if last_total > 0 and current_total > 0:
            percent_change = ((current_total - last_total) / last_total) * 100
            
            if percent_change > 20:
                insights.append({
                    'id': 'spending-increase',
                    'type': 'warning',
                    'title': 'Spending Up',
                    'message': f"You've spent {int(percent_change)}% more than last month so far.",
                    'icon': '📈'
                })
            elif percent_change < -15:
                insights.append({
                    'id': 'spending-decrease',
                    'type': 'achievement',
                    'title': 'Great Progress!',
                    'message': f"You're spending {int(abs(percent_change))}% less than last month! Keep it up!",
                    'icon': '🎉'
                })
        
        # 3. Category-wise comparisons
        categories_current = {}
        for exp in current_month_expenses:
            cat = exp['category']
            categories_current[cat] = categories_current.get(cat, 0) + exp['amount']
        
        categories_last = {}
        for exp in last_month_expenses:
            cat = exp['category']
            categories_last[cat] = categories_last.get(cat, 0) + exp['amount']
        
        category_icons = {
            'food': '🍔', 'travel': '🚗', 'shopping': '🛍️', 'rent': '🏠',
            'utilities': '💡', 'entertainment': '🎬', 'health': '⚕️', 'other': '📌'
        }
        
        for category, amount in categories_current.items():
            last_amount = categories_last.get(category, 0)
            if last_amount > 0:
                percent_change = ((amount - last_amount) / last_amount) * 100
                if percent_change > 35:
                    cat_name = category.replace('_', ' ').title()
                    icon = category_icons.get(category, '📌')
                    insights.append({
                        'id': f'category-spike-{category}',
                        'type': 'warning',
                        'title': f'{icon} {cat_name} Spike',
                        'message': f"You've spent {int(percent_change)}% more on {category.lower()} compared to last month.",
                        'icon': icon
                    })
        
        # 4. Category budget warnings
        for category, limit in budget_dict.items():
            if category != 'total':
                spent = categories_current.get(category, 0)
                if spent > limit:
                    cat_name = category.replace('_', ' ').title()
                    icon = category_icons.get(category, '📌')
                    overage = spent - limit
                    insights.append({
                        'id': f'budget-exceeded-{category}',
                        'type': 'warning',
                        'title': 'Budget Exceeded',
                        'message': f"You've exceeded your {category.lower()} budget by ₹{int(overage):,}.",
                        'icon': icon
                    })
        
        return jsonify(insights), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
