-- Create budgets table
CREATE TABLE IF NOT EXISTS budgets (
  id INT PRIMARY KEY AUTO_INCREMENT,
  category VARCHAR(50) NOT NULL,
  monthly_limit DECIMAL(10, 2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY unique_category (category)
);

-- Add a note field to expenses if not exists
ALTER TABLE expenses ADD COLUMN IF NOT EXISTS note VARCHAR(255);

-- Insert default budgets
INSERT INTO budgets (category, monthly_limit) VALUES
  ('total', 50000),
  ('food', 10000),
  ('travel', 5000),
  ('shopping', 8000),
  ('rent', 15000),
  ('utilities', 3000),
  ('entertainment', 5000),
  ('health', 3000),
  ('other', 1000)
ON DUPLICATE KEY UPDATE monthly_limit = VALUES(monthly_limit);
